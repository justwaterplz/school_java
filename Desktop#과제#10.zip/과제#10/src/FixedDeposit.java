//���⿹��
public class FixedDeposit extends Deposit {
	
	//����
	private int principle;
	//������
	private int result;
	
	public FixedDeposit(String name,int number,int month,double interest,int principle) 
	{
		super(name,number,month,interest);
		this.setPrinciple(principle);
		this.result = 0;
	}
	
	public int getPrinciple()
	{
		return this.principle;
	}
	public void setPrinciple(int principle)
	{
		this.principle = principle;
	}
	public void setResult(int money)
	{
		this.result = money;
	}
	public int getResult()
	{
		return this.result;
	}
	
	public void calcInterest()
	{
		//
	}
	
	public String toString()
	{
		return super.toString() + "����: " + this.getPrinciple();
	}

}
