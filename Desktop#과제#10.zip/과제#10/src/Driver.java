
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Savings sav = new Savings("�浿",300,12,0.05,100000);
	//	CompoundDeposit cd = new CompoundDeposit("����", 200, 12, 0.05, 100000);
	//	IsolatedDeposit id = new IsolatedDeposit("�浿", 100, 12, 0.05, 100000);
		
		
		System.out.println(sav.toString());
	//	System.out.println(cd.toString());
	//	System.out.println(id.toString());
	}

}
