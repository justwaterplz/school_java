//�ܸ� ���⿹��
public class IsolatedDeposit extends FixedDeposit{

	public IsolatedDeposit(String name,int number,int month,double interest,int principle)
	{
		super(name,number,month,interest,principle);
		
	}
	
	public void calcInterest()
	{
		this.setResult(this.getPrinciple() * (1 + (int)(this.getInterest()/12) * this.getContract()) );
	}
	
	public String toString()
	{
		return "���⿹��(�ܸ�)\n" + super.toString() + "������: " + this.getResult();
	}
	
}
