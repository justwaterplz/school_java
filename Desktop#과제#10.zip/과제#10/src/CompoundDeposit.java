//���� ���⿹��
public class CompoundDeposit extends FixedDeposit{

	public CompoundDeposit(String name,int number,int month,double interest,int principle)
	{
		super(name,number,month,interest,principle);
	}
	
	public void calcInterest()
	{
		//����: principle * (1 + (interest / 12))^contract
		double interest = (1 + (this.getInterest() / 12));
		for(int i = 0; i < this.getContract(); i++)
		{
			interest *= interest;
		}
		this.setResult(getPrinciple() * (int)interest);
	}
	
	public String toString()
	{
		return "���⿹��(����)\n" + super.toString() + "������: " + this.getResult();
	}
}
