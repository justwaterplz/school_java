import java.util.*;
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		SalesReport report = new SalesReport();
		
		report.createSalesman();
		
		report.calculateSales();
		report.findBestEmployee();
	}

}
