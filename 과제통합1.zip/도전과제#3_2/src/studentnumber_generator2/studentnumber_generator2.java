package studentnumber_generator2;
import java.util.*;
public class studentnumber_generator2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		String stu_name,admission_year,admission_type;
		String stu_num = "60",admission_num;
		int stu_count = 0;
		
		System.out.println("name: ");
		stu_name = scanner.next();
		
		System.out.println("year: ");
		admission_year = scanner.next();
		
		System.out.println("type: ");
		admission_type = scanner.next();
		
		stu_num = stu_num + admission_year.substring(2,4);
		
		//6018
		if(admission_type.equals("���Ի�"))
		{
			
			admission_num = "2";
			stu_num += admission_num;
			stu_count++;
		}
		else if(admission_type.equals("���Ի�"))
		{
			admission_num = "5";
			stu_num += admission_num;
			stu_count++;
		}
		else
		{
			System.out.println("false input.");
		}
		
		System.out.println("your name: " + stu_name);
		System.out.println("your studnet num: " + stu_num + String.format("%03d",stu_count));
		
		scanner.close();
	}

}
