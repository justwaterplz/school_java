
public class TelevisionDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Television tv1 = new Television();
		
		tv1.setBrandName("�Ｚ");
		
		//���� on
		tv1.turnPowerOn();
		//ä�� 1 ���� 6����
		tv1.setChannel(1);
		tv1.setVolume(6);
		
		tv1.printStatus();
	}

}
