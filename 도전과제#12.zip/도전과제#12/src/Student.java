//�л��� ��Ÿ���� Ŭ����
public class Student {
	//�л��� �й�, �̸�, ����, ��ȭ��ȣ, �ּ�, �а�, ��̿� �ڱ� �Ұ��� ������. 
	private String studentNum;
	private String studentName;
	//�� / ���θ� ����
	private String studentGender;
	private String phoneNum;
	private String studentAddress;
	private String studentMajor;
	private String studentHobby;
	private String studentIntro;
	
	//�־��� ������ ��������� �ʱ�ȭ�ϸ� ��ü ����
	Student(String nubmer,String name,String gender,String phone,String address,String major,String hobby,String intro)
	{
		this.setNum(nubmer);
		this.setName(name);
		this.setGender(gender);
		this.setPhoneNumber(phone);
		this.setAddress(address);
		this.setMajor(major);
		this.setHobby(hobby);
		this.setIntro(intro);
	}
	
	//set
	public void setName(String name)
	{
		this.studentName = name;
	}
	public void setNum(String number)
	{
		this.studentNum = number;
	}
	public void setGender(String gender)
	{
		this.studentGender = gender;
	}
	public void setPhoneNumber(String number)
	{
		this.phoneNum = number;
	}
	public void setAddress(String address)
	{
		this.studentAddress = address;
	}
	public void setMajor(String major)
	{
		this.studentMajor = major;
	}
	public void setHobby(String hobby)
	{
		this.studentHobby = hobby;
	}
	public void setIntro(String intro)
	{
		this.studentIntro = intro;
	}
	
	//get
	public String getStudentNum()
	{
		return this.studentNum;
	}
	public String getStudentName()
	{
		return this.studentName;
	}
	public String getStudentGender()
	{
		return this.studentGender;
	}
	public String getStudentPhone()
	{
		return this.phoneNum;
	}
	public String getStudentAddress()
	{
		return this.studentAddress;
	}
	public String getStudentMajor()
	{
		return this.studentMajor;
	}
	public String getStudentHobby()
	{
		return this.studentHobby;
	}
	public String getStudentIntro()
	{
		return this.studentIntro;
	}
	
	public String toString()
	{
		return this.getStudentNum() + " " + this.getStudentName() + " " + this.getStudentGender() + "\t" +
	this.getStudentPhone() + " " + this.getStudentAddress() + " " + this.getStudentMajor() + " " + this.getStudentHobby() + " " + this.getStudentIntro();
	}
}
