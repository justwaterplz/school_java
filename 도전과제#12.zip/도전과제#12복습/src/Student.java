
public class Student {
	private String studentNum;
	private String studentName;
	private String studentGender;
	private String phoneNum;
	private String studentAddr;
	private String studentMajor;
	private String studentIntro;
	private String studentHobby;
	
	Student(String num,String name,String gender,String phone,String addr,String major,String hobby,String intro)
	{
		this.studentNum = num;
		this.studentName = name;
		this.studentGender = gender;
		this.phoneNum = phone;
		this.studentAddr = addr;
		this.studentMajor = major;
		this.studentIntro = intro;
		this.studentHobby = hobby;
	}
	
	public String toString()
	{
		return this.studentNum + "    " + this.studentName + "   " + this.studentGender + "\t" + 
				this.phoneNum + "\t" + this.studentAddr + "\t" + this.studentMajor + "\t" + this.studentIntro;
	}
}
