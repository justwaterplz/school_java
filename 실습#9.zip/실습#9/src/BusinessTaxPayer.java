//사업소득자를 나타내는 클래스
public class BusinessTaxPayer extends TaxPayer{
	//총매출액과 총비용
	private int sales;
	private int expense;
	
	public BusinessTaxPayer(String name, int num,int sales,int expense)
	{
		super(name,num);
		this.setSales(sales);
		this.setExpense(expense);
	}
	
	//get
	public int getSales()
	{
		return this.sales;
	}
	public int getExpense()
	{
		return this.expense;
	}
	
	//set
	public void setSales(int sales)
	{
		this.sales = sales;
	}
	public void setExpense(int expense)
	{
		this.expense = expense;
	}
	
	public String toString()
	{
		return super.toString() + ", 총매출액: " + this.getSales() + ", 총비용: " + this.getExpense(); 
	}
	
	public double calcTax()
	{
		//과세 대상금액 지역변수.과세대상금액 = 총매출액 – 총비용
		double amountTaxable = this.getSales() - this.getExpense();
		double tax;
		
		if(amountTaxable <= 0)
		{
			//세금이 0이다.
			tax = 0;
		}
		else if(amountTaxable <= 40000000)
		{
			tax = amountTaxable * 0.1;
		}
		else
		{
			tax = amountTaxable * 0.2;
		}
		return tax;
	}
}
